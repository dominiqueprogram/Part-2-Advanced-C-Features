using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeApp;

namespace RecipeAppTests
{
    //[TestClass]
    public class RecipeTests
    {
        //[TestMethod]
        public void CalculateTotalCalories_ShouldReturnZero_WhenNoIngredients()
        {
            // Arrange
            Recipe recipe = new Recipe();

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(0, totalCalories);
        }

        //[TestMethod]
        public void CalculateTotalCalories_ShouldReturnCorrectSum_WhenIngredientsPresent()
        {
            // Arrange
            Recipe recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Calories = 100 });
            recipe.Ingredients.Add(new Ingredient { Calories = 200 });
            recipe.Ingredients.Add(new Ingredient { Calories = 150 });

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(450, totalCalories);
        }

        //[TestMethod]
        public void CalculateTotalCalories_ShouldHandleZeroCalories_WhenIngredientsWithZeroCaloriesPresent()
        {
            // Arrange
            Recipe recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Calories = 100 });
            recipe.Ingredients.Add(new Ingredient { Calories = 0 });
            recipe.Ingredients.Add(new Ingredient { Calories = 150 });

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(250, totalCalories);
        }

        //[TestMethod]
        public void CalculateTotalCalories_ShouldHandleNegativeCalories_WhenIngredientsWithNegativeCaloriesPresent()
        {
            // Arrange
            Recipe recipe = new Recipe();
            recipe.Ingredients.Add(new Ingredient { Calories = 100 });
            recipe.Ingredients.Add(new Ingredient { Calories = -50 });
            recipe.Ingredients.Add(new Ingredient { Calories = 150 });

            // Act
            int totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(200, totalCalories);
        }
    }
}
